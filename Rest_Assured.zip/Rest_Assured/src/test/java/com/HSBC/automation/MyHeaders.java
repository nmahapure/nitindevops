package com.HSBC.automation;

import java.util.HashMap;
import java.util.Map;

import com.jayway.restassured.response.Header;

public class MyHeaders {
	
	public static Header getHeaders;

	public static Map<String, String> getHeaders() {
		Map<String, String> headers = new HashMap<>();
		
		headers.put("Date","Mon, 01 Jul 2019 09:23:36 GMT");
		headers.put("Content-Type", "application/json;charset=utf-8");
		headers.put("Access-Control-Allow-Origin", "*");
		headers.put("Access-Control-Allow-Methods", "GET");
		headers.put("Access-Control-Allow-Headers", "Accept, X-Requested-With");
		headers.put("Cache-Control", "public, max-age=86400");
		headers.put("Server", "cloudflare");
		headers.put("CF-RAY", "4ef75278bac9d1af-HKG");
		headers.put("Content-Encoding ", "gzip");
		headers.put("Content-Length ", "522");
		headers.put("Age  ", "0");
		headers.put("Via", "1.1 wbsn-pun-cluster");
		

		
		return headers;
		
	}

}
