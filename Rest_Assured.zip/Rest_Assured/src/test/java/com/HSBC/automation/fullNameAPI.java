package com.HSBC.automation;

import static org.junit.Assert.assertThat;

import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.http.Method;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Headers;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

public class fullNameAPI {

	@Test
	public void expected_Catagery_Sucess_Response() {

		Response response = getResponse();
		String responseBody = response.getBody().asString();

		System.out.println("Response Body is =>  " + responseBody);

		Assert.assertTrue(response.statusCode() == HttpStatus.SC_OK);

		// assertThat(response.getFirstName()).isEqualTo("John");

	}

	@Test
	public void expected_Catagery_Print_Response() {

		// Response response =
		// RestAssured.given().headers(Headers.getHeaders()).accept(ContentType.JSON).basePath("http://restcountries.eu").baseUri("/rest/v2/name/eesti").get();

		Response response = getResponse();

		String responseBody = response.getBody().asString();

		//System.out.println("Response Body is =>  " + responseBody);

		System.out.println("country names are =>  " + response.jsonPath().getList("alpha2Code"));

	}

	@Ignore
	public void expected_Catagery_Validate_NameOf_Country() {

		// Response response =
		// RestAssured.given().headers(Headers.getHeaders()).accept(ContentType.JSON).basePath("http://restcountries.eu").baseUri("/rest/v2/name/eesti").get();

		Response response = getResponse();

		Assert.assertEquals(response.jsonPath().getList("name").get(0), "Aruba");

		Assert.assertEquals(response.jsonPath().getList("capital").get(0), "Oranjestad");

	}

	@Ignore
	public void expected_Catagery_Print_Response_Headers() {

		// Response response =
		// RestAssured.given().headers(Headers.getHeaders()).accept(ContentType.JSON).basePath("http://restcountries.eu").baseUri("/rest/v2/name/eesti").get();

		Response response = getResponse();

		Headers headers = response.getHeaders();

		System.out.println("headers are =>  " + headers);

	}

	@Ignore
	public void expected_Catagery_Print_Request_MyHeaders() {
		// Response response =
		// RestAssured.given().headers(Headers.getHeaders()).accept(ContentType.JSON).basePath("http://restcountries.eu").baseUri("/rest/v2/name/eesti").get();

		Response response = RestAssured.given().when().get("http://restcountries.eu/rest/v2/name/aruba?fullText=true");

		Assert.assertTrue(response.statusCode() == HttpStatus.SC_OK);

		System.out.println("Headers response is : " + response);
		// System.out.println("Response Body with changed request manupulated headers =>
		// " + responseBody);
	}

	@Ignore
	public void expected_Catagery_Validate_Bad_Request() {

		Response response = RestAssured.given().when().get("http://restcountries.eu/resta/v2/name/aruba?fullText=true");

		Assert.assertTrue(response.statusCode() == HttpStatus.SC_NOT_FOUND);

	}

	@Ignore
	public void expected_Catagery_Print_TimeZone_Of_Australia_Country() {

		Response response = RestAssured.given().when()
				.get("http://restcountries.eu/rest/v2/name/australia?fullText=true");

		System.out.println("timezones of Australia  " + response.jsonPath().getList("timezones"));

		System.out.println("currencies of Australia  " + response.jsonPath().getList("currencies"));

	}

	@Ignore
	public void expected_Catagory_Print_TimeZone_of_India_Country() {

		Response response = RestAssured.given().when().get("http://restcountries.eu/rest/v2/name/india?fullText=true");

		System.out.println("translations of India  " + response.jsonPath().getList("translations"));
	}

	@Ignore
	public void validateDateOfUSCountry() {

		Response response = RestAssured.given().when().get("http://restcountries.eu/rest/v2/name/uk?fullText=true");

		System.out.println("Details of UK country is " + response.jsonPath().getList("languages"));

	}

	private Response getResponse() {
		Response response = RestAssured.given().when().get("http://restcountries.eu/rest/v2/name/aruba?fullText=true");
		return response;
	}

}